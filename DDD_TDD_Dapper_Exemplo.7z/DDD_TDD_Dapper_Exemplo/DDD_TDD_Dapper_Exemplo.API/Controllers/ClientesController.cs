﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using DDD_TDD_Dapper_Exemplo.Aplicacao.Interfaces;
using DDD_TDD_Dapper_Exemplo.Dominio.Entidades;

namespace DDD_TDD_Dapper_Exemplo.API.Controllers
{
    [Produces("application/json")]
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}/[controller]")]
    //[Authorize]
    public class ClientesController : Controller
    {
        protected IClienteAppServico _servico;

        public ClientesController(IClienteAppServico clienteServico)
        {
            _servico = clienteServico;
        }

        [HttpGet]
        public IEnumerable<Cliente> Get()
        {
            return _servico.GetAll();
        }

        [HttpGet("{id}", Name = "Get")]
        public Cliente Get(int id)
        {
            return _servico.GetbyId(id);
        }
        
        [HttpPost]
        public void Post([FromBody]Cliente cliente)
        {
            _servico.Adicionar(cliente);
        }
        
        [HttpPut("{id}")]
        public void Put([FromBody]Cliente cliente)
        {
            _servico.Atualizar(cliente);
        }
        
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            _servico.Remover(id);
        }
    }
}
