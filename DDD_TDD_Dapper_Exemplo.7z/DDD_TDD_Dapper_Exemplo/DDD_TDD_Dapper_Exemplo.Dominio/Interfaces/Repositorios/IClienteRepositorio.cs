﻿using DDD_TDD_Dapper_Exemplo.Dominio.Entidades;

namespace DDD_TDD_Dapper_Exemplo.Dominio.Interfaces.Repositorios
{
    public interface IClienteRepositorio:IClienteRepositorio<Cliente>
    {
    }
}
